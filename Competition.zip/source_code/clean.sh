#!/bin/bash
rm -f *.exe *.out *.bin *.o *.gcno *.gcda *.gcov ./func_tests/data/cmp_file ./func_tests/data/trash ./func_tests/data/out ./func_tests/data/bin* ./func_tests/data/out*