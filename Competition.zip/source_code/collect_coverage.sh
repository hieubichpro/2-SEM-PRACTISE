#!/bin/bash
bash run_tests.sh
gcov ./main.c