#!/bin/bash
cd func_tests/scripts/
bash func_test.sh
cd ../../