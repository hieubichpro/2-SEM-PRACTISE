#include "my_funcs.h"

int main(int argc, char **argv)
{
    FILE *f1, *f2;
    f1 = fopen(argv[1], "r");
    student students[MAX_NUM_ELE];
    int read = 1;
    int i = 0;
    int rc = OK;
    string tmp1, tmp2;  
    while (read)
    {
        if (feof(f1))
            break;
        
        if (fscanf(f1, "%s %s", tmp1, tmp2) != 2)
        {
            rc = ERR_FILE;
            break;
        }
        if (strlen(tmp1) > MAX_LEN_SUR - 1 || strlen(tmp2) > MAX_LEN_NAME - 1)
        {
            rc = ERR_FILE;
            break;
        }
        strcpy(students[i].surname, tmp1);
        strcpy(students[i].name, tmp2);
        for (int j = 0; j < NUMBER_OF_MARKS; j++)
            if (fscanf(f1, "%u", &students[i].marks[j]) != 1)
                {
                    rc = ERR_FILE;
                    break;
                }
        i++;
    }
    if (rc != OK)
        return ERR_FILE;
    f2 = fopen(argv[2], "wb");
    for (int j = 0; j < i; j++)
        fwrite(&students[j], sizeof(student), 1, f2);
    fclose(f2);
    fclose(f1);
    return OK;
}