#include "my_funcs.h"

int main(int argc, char **argv)
{
    FILE *f1, *f2;
    f1 = fopen(argv[1], "rb");
    if (f1 == NULL)
        return ERR_FILE;
    student students[MAX_NUM_ELE];
    size_t sz;
    int rc = file_size(f1, &sz);
    if (rc != OK)
        return ERR_FILE;
    sz /= sizeof(student);
    for (size_t j = 0; j < sz; j++)
    {
        if (fread(&students[j], sizeof(student), 1, f1) != 1)
        {
            rc = ERR_FILE;
            break;
        }
    }

    if (rc != OK)
        return ERR_FILE;
    f2 = fopen(argv[2], "w");
    for (size_t k = 0; k < sz; k++)
    {
        fprintf(f2, "%s\n%s\n", students[k].surname, students[k].name);
        for (int p = 0; p < NUMBER_OF_MARKS; p++)
        {
            if (p == NUMBER_OF_MARKS - 1)
                fprintf(f2, "%u", students[k].marks[p]);
            else
                fprintf(f2, "%u ", students[k].marks[p]);
        }
        if (k != sz - 1)
            fprintf(f2, "\n");
    }
    fclose(f1);
    fclose(f2);
    return OK;
}