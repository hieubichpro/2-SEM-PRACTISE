#!/bin/bash
funcs="dot_mt_1 dot_mt_2"
opts="O1 O2 O3 O0 Os"
sizes="10 25 50 75 100 125 150 200 250 300 350 400 450 500"

for opt in $opts; do
    for func in $funcs; do
        for size in $sizes; do
            gcc -std=c99 -Wall -Werror -Wpedantic -Wextra \
                -"${opt}" \
                -DFUNC="${func}" \
                -DNMAX="${size}" main.c -o ./apps/app_"${func}"_"${opt}"_"${size}".exe
        done
    done
done