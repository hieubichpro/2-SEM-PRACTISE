#!/bin/bash

gnuplot -persist linear.gpi