#!/bin/bash
echo "building applications"
bash build_apps.sh
echo "apps were built"
bash update_data.sh "" "" "" 10
bash make_preproc.sh
bash make_postproc.sh