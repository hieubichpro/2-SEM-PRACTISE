#include <stdio.h>
#include <stdlib.h>

#define N 10000

double find_middle(double a[], int st, int end)

{
    int i = st;
    int j = end;
    while (i < j)
    {
        i ++;
        j --;
    }
    if (i > j)
        return (a[j] + a[i]) / 2;
    else
        return a[i];
}

void sort(double a[], int n)
{
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (a[j] < a[i])
            {
                double temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
}

int main(void)
{
    double arr[N];
    int len = 0;
    double temp;
    double sum = 0.0;
    double median, lower_quartile, upper_quartile;
    if (scanf("%lf", &temp) == 1)
    {
        arr[len] = temp;
        sum += temp;
        len++;
    }
    while (scanf("%lf", &temp) == 1)
    {
        arr[len] = temp;
        sum += temp;
        len++;
    }
    
    sort(arr, len);

    median = find_middle(arr, 0, len - 1);
    if (len % 2 == 0)
    {
        lower_quartile = find_middle(arr, 0, len / 2 - 1);
        upper_quartile = find_middle(arr, len / 2, len - 1);
    }
    else
    {
        lower_quartile = find_middle(arr, 0, len / 2 - 1);
        upper_quartile = find_middle(arr, len / 2 + 1, len - 1);
    }
    printf("%lf %lf %lf %lf %lf %lf\n",sum / len, arr[len - 1], arr[0], lower_quartile, median, upper_quartile);

    return 0;
}