#!/bin/bash

funcs="dot_mt_1 dot_mt_2"
sizes="10 25 50 75 100 125 150 200 250 300 350 400 450 500"
opts="O1 O2 O3 O0 Os"
count=1

if [ ! -z $1 ]; then
    funcs=$1
fi

if [ ! -z $2 ]; then
    opts=$2
fi

if [ ! -z $3 ]; then
    sizes=$3
fi

if [ ! -z $4 ]; then
    count=$4
fi

for cnt in $(seq "$count"); do
    for func in $funcs; do
        for opt in $opts; do
            for size in $sizes; do
                echo -n -e "$cnt/$count $func $opt $size \r"
                ./apps/app_"${func}"_"${opt}"_"${size}".exe >> ./data/"${func}"_"${opt}"_"${size}".txt
            done
        done
    done
done