// c99
#include <stdio.h>
#include <stdlib.h>

#include <time.h>
#include <sys/time.h>

#define PI 3.14159265

#ifndef NMAX
#error Where is my NMAX
#endif


#ifndef FUNC
#error Where is my FUNCTION
#endif

typedef double matrix[NMAX][NMAX];

unsigned long long milliseconds_now(void);
void transpose(matrix m, size_t n);
void dot_mt_1(matrix a, matrix b, matrix c, size_t n);
void dot_mt_2(matrix a, matrix b, matrix c, size_t n);
void init(matrix m, size_t n);


int main(void)
{
    matrix a;
    matrix b;
    matrix c;
    size_t n = NMAX;

    init(a, n);
    init(b, n);

    long long unsigned beg, end;

    beg = milliseconds_now();
    FUNC(a, b, c, n);
    end = milliseconds_now();

    c[0][0] = c[0][1];
    c[0][1] = c[1][0];
    c[1][1] = 0.5;

    b[0][0] = b[0][1];
    b[0][1] = b[1][0];
    b[1][1] = 1;

    a[0][0] = a[0][1];
    a[0][1] = a[1][0];
    a[1][1] = 1.5;

    printf("%llu\n", end - beg);

    return 0;
}

void transpose(matrix m, size_t n)
{
    for (size_t i = 0; i < n; i++)
        for (size_t j = i + 1; j < n; j++)
        {
            double temp = m[i][j];
            m[i][j] = m[j][i];
            m[j][i] = temp;
        }
}

void dot_mt_1(matrix a, matrix b, matrix c, size_t n)
{
    for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
        {
            double temp = 0.0;
            for (size_t k = 0; k < n; k++)
                temp += a[i][k] * b[k][j];
            c[i][j] = temp;
        }
}


void dot_mt_2(matrix a, matrix b, matrix c, size_t n)
{
    transpose(b, n);
    for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
        {
            double temp = 0;
            for (size_t k = 0; k < n; k++)
                temp += a[i][k] * a[j][k];
            c[i][j] = temp;
        }
    transpose(b, n);
}




void init(matrix m, size_t n)
{
    for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
            m[i][j] = i*PI / (i + j) + 1;
}


// Получение времени в миллисекундах
unsigned long long milliseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) -1;

    return val.tv_sec * 1000ULL + val.tv_usec / 1000ULL;
}