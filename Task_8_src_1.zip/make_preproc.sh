#!/bin/bash

files=$(ls ./data/)

for file in $files; do
    ./prepdata.exe < ./data/$file > ./prepdata/$file
done

funcs="dot_mt_1 dot_mt_2"
sizes="10 25 50 75 100 125 150 200 250 300 350 400 450 500"
opts="O1 O2 O3 O0 Os"

rm -rf ./posproc/*.txt
for size in $sizes; do
    for func in $funcs; do
        for opt in $opts; do
            if [ -f "./prepdata/${func}_${opt}_${size}.txt" ]; then
                echo "$size $(cat ./prepdata/${func}_${opt}_${size}.txt)" >> ./posproc/"${func}_${opt}_data.txt"
            fi
        done
    done
done